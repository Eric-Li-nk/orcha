import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orcha',
  templateUrl: './orcha.component.html',
  styleUrls: ['../../css/style.css']
})
export class OrchaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
